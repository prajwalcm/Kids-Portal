package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbConnection {

	public static Connection getConnection()

	{
		Connection con = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kidsportal", "root", "");
			return con;
		}
		catch (Exception e) 
		{
			System.out.println("Exception is " + e);

		}
		return con;
	}

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub  
		
		

	}



	public static String getClass(String userid) {
		String clas=null;
		try {
			ResultSet rs=getConnection().createStatement().executeQuery("select * from studentreg where id="+userid);
			while(rs.next()){
				clas=rs.getString("class");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clas;
	}

}
