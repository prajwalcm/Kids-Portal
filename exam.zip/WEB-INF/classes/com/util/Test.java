package com.util;

import java.awt.image.BufferedImage;
import java.io.*;
import java.security.MessageDigest;

import javax.imageio.ImageIO;

public class Test {
public static void main(String[] args)throws Exception {
	//File f1 = new File("C:\\Users\\Admin\\Desktop\\icecream\\New folder\\9.jpg");
	BufferedImage buffImg = ImageIO.read(new File("C:\\Users\\Admin\\Desktop\\icecream\\New folder\\9.jpg"));
	 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	 ImageIO.write(buffImg, "png" ,outputStream);
	 byte[] data = outputStream.toByteArray();
	 System.out.println("Start MD5 Digest");
	 System.out.println("Start MD5 Digest");
       MessageDigest md = MessageDigest.getInstance("MD5");
	 md.update(data);
       byte[] hash = md.digest();
       System.out.println(returnHex(hash).substring(4));
	
}

private static String returnHex(byte[] inBytes) {
	String hexString = null;
    for (int i=0; i < inBytes.length; i++) 
    { //for loop ID:1
        hexString +=
        Integer.toString( ( inBytes[i] & 0xff ) + 0x100, 16).substring( 1 );
    }                                   // Belongs to for loop ID:1
return hexString;
}
}
