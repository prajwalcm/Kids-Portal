package com.kids;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.DbConnection;


@WebServlet("/exam")
public class exam extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public exam() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession();
String userid = session.getAttribute("studid").toString();
String exam = request.getParameter("exam");


		String ans1 = request.getParameter("1");
		String ans2 = request.getParameter("2");
		String ans3 = request.getParameter("3");
		String ans4 = request.getParameter("4");
		String ans5 = request.getParameter("5");
		String ans6 = request.getParameter("6");
		String ans7 = request.getParameter("7");
		String ans8 = request.getParameter("8");
		String ans9 = request.getParameter("9");
		String ans10 = request.getParameter("10");
		
		String id1 = request.getParameter("id1");
		String id2 = request.getParameter("id2");
		String id3 = request.getParameter("id3");
		String id4 = request.getParameter("id4");
		String id5 = request.getParameter("id5");
		String id6 = request.getParameter("id6");
		String id7 = request.getParameter("id7");
		String id8 = request.getParameter("id8");
		String id9 = request.getParameter("id9");
		String id10 = request.getParameter("id10");
		//System.out.println(ans1);
		//System.out.println(ans2);
		 
		try {
			Connection con = DbConnection.getConnection();
			 int marks = 0;
			PreparedStatement ps = con.prepareStatement("select * from exam where id=?");
			ps.setString(1, id1);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				if(ans1.equals(rs.getString("answer")))
				{
					System.out.println("ans1");
					marks++;
				}
			}
			
			
			ps.setString(1, id2);
			ResultSet rs2 = ps.executeQuery();
			if(rs2.next())
			{
				if(ans2.equals(rs2.getString("answer")))
				{
					System.out.println("ans2");
					marks++;
				}
			}
			
			
			ps.setString(1, id3);
			ResultSet rs3 = ps.executeQuery();
			if(rs3.next())
			{
				if(ans3.equals(rs3.getString("answer")))
				{
					System.out.println("ans3");
					marks++;
				}
			}
			
			
			ps.setString(1, id4);
			ResultSet rs4 = ps.executeQuery();
			if(rs4.next())
			{
				if(ans4.equals(rs4.getString("answer")))
				{
					System.out.println("ans4");
					marks++;
				}
			}
			
			
			ps.setString(1, id5);
			ResultSet rs5 = ps.executeQuery();
			if(rs5.next())
			{
				if(ans5.equals(rs5.getString("answer")))
				{
					System.out.println("ans5");
					marks++;
				}
			}
			
			
			
			ps.setString(1, id6);
			ResultSet rs6 = ps.executeQuery();
			if(rs6.next())
			{
				if(ans6.equals(rs6.getString("answer")))
				{
					System.out.println("ans6");
					marks++;
				}
			}
			
			
			ps.setString(1, id7);
			ResultSet rs7 = ps.executeQuery();
			if(rs7.next())
			{
				if(ans7.equals(rs7.getString("answer")))
				{
					System.out.println("ans7");
					marks++;
				}
			}
			
			
			
			ps.setString(1, id8);
			ResultSet rs8 = ps.executeQuery();
			if(rs8.next())
			{
				if(ans8.equals(rs8.getString("answer")))
				{
					System.out.println("ans8");
					marks++;
				}
			}
			
			
			
			ps.setString(1, id9);
			ResultSet rs9 = ps.executeQuery();
			if(rs9.next())
			{
				if(ans9.equals(rs9.getString("answer")))
				{
					System.out.println("ans9");
					marks++;
				}
			}
			
			
			ps.setString(1, id10);
			ResultSet rs10 = ps.executeQuery();
			if(rs10.next())
			{
				if(ans10.equals(rs10.getString("answer")))
				{
					System.out.println("ans10");
					marks++;
				}
			}
			 
			StoreData(userid, Integer.toString(marks), exam);
			 System.out.println(marks);
			 response.sendRedirect("result.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	public void StoreData(String userid,String marks,String coloumn)throws Exception
	{
		Connection con = DbConnection.getConnection();
		PreparedStatement ps = con.prepareStatement("select * from result where userid=?");
		ps.setString(1, userid);
		String clas=DbConnection.getClass(userid);
		System.out.println("user class:    "+clas);
		ResultSet rs = ps.executeQuery();
		
		String sql3="update result set class='"+clas+"' where userid="+userid;
		System.out.println(sql3);
		PreparedStatement ps3 = con.prepareStatement(sql3);
		ps3.executeUpdate();
		
		if(!rs.next())
		{
			String sql = "insert into result(userid) values('"+userid+"')";
			PreparedStatement ps1 = con.prepareStatement(sql);
			ps1.executeUpdate();
			
			/*String sql3="update result set class='"+clas+"' where userid="+userid;
			System.out.println(sql3);
			PreparedStatement ps3 = con.prepareStatement(sql3);
			ps3.executeUpdate();*/
			
			String sql2 = "update result set "+coloumn+"="+marks+" where userid="+userid;
			PreparedStatement ps2 = con.prepareStatement(sql2);
			ps2.executeUpdate();
		}
		else
		{
			String sql2 = "update result set "+coloumn+"="+marks+" where userid="+userid;
			PreparedStatement ps2 = con.prepareStatement(sql2);
			ps2.executeUpdate();
		}
		
	}

}
