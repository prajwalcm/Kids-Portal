package com.kids;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import pack1.SendMailSSL;


import javax.servlet.http.HttpSession;

import com.sms.SMS;
import com.util.DbConnection;


@WebServlet("/InformParents")
public class InformParents extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public InformParents() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		session.getAttribute("userid");
		
		try {
			
			String userid=request.getParameter("id");
			Connection con=DbConnection.getConnection();
			PreparedStatement ps1=con.prepareStatement("select * from studentreg");
			//ps1.setString(1, userid);
			ResultSet rs=ps1.executeQuery();
			//String mobile="";
			System.out.println("mobile: "+userid);
			while(rs.next())
			{
				
				String mobile=rs.getString("mobile");
				
				SMS sms=new SMS();
				String msgC="Meeting with Principal. Your child Overall-attendance is very less.";
				String myURL = "http://sms.wecreatead.com/API/WebSMS/Http/v1.0a/index.php";
				
					mobile=rs.getString("mobile");
					SMS.callURL("",msgC, mobile);
				}
					
				System.out.println("SMS Send Successfully");
				response.sendRedirect("principlehome.jsp?sent");

			} catch (Exception e) {
			e.printStackTrace();
		}

	}
}		
