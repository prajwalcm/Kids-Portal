package com.kids;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.IOException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 




import com.util.DbConnection;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class SentFiles
 */
@WebServlet("/SentFiles")
public class SentFiles extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SentFiles() {
        super();
        // TODO Auto-generated constructor stub
    }

    Connection con = null;
	final String UPLOAD_DIRECTORY = "D:\\Testing\\KidsPortal\\WebContent\\exam\\";
	static int i = 0;

	public void init(ServletConfig config) throws ServletException {
		try {
			con = DbConnection.getConnection();

		} catch (Exception e) {

			System.out.println("Exception in DB" + e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("in do post");

		ArrayList<String> arr=new ArrayList<String>();
		HttpSession session=request.getSession();
		String hid=(String)session.getAttribute("hid");
		
		
		if (ServletFileUpload.isMultipartContent(request)) 
		{
			System.out.println("1");
			
			
			try {
				List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
									
					System.out.println("ABCD");
					String FileName = "";
					String FileExtention = "";
					long FileSize = 0;
					int i=0;
					
					
					

					for (FileItem item1 : multiparts) 
					{
						if (!item1.isFormField()) 
						{

							System.out.println("4");
							String name = new File(item1.getName()).getName();
							item1.write(new File(UPLOAD_DIRECTORY + File.separator + name));
							FileName = item1.getName();
							FileExtention = item1.getContentType();
							FileSize = item1.getSize();
							arr.add(FileName);
							
						}
					}

					int iop=0;
					String f1="",f2="",f3="",f4="",f5="";
					String subject="";
					String question="";
					for(String s:arr)
					{
						iop=iop+1;
						
						if(iop==1)
						{
							f1=s;
						}
						if(iop==2)
						{
							f2=s;
						}
						if(iop==3)
						{
							f3=s;
						}
						if(iop==4)
						{
							f4=s;
						}
						if(iop==5)
						{
							f5=s;
						}
						
					}
					for (FileItem item : multiparts) 
					{
						if ((item.getFieldName()).equals("subject")) 
						{
							subject = (String) item.getString();
						}
					}
					for (FileItem item : multiparts) 
					{
						if ((item.getFieldName()).equals("question")) 
						{
							question = (String) item.getString();
						}
					}

					System.out.println(question);
					System.out.println(subject);
					String choice1 = Messagedigest(UPLOAD_DIRECTORY+f1);
					String choice2 = Messagedigest(UPLOAD_DIRECTORY+f2);
					String choice3 = Messagedigest(UPLOAD_DIRECTORY+f3);
					String choice4 = Messagedigest(UPLOAD_DIRECTORY+f4);
					String choice5 = Messagedigest(UPLOAD_DIRECTORY+f5);

					 

			       PreparedStatement ps = con.prepareStatement("insert into exam(aimage,a,bimage,b,cimage,c,dimage,d,answer,subject,question) values(?,?,?,?,?,?,?,?,?,?,?)");
			       ps.setString(1, f1);
			       ps.setString(2, choice1);
			       ps.setString(3, f2);
			       ps.setString(4, choice2);
			       ps.setString(5, f3);
			       ps.setString(6, choice3);
			       ps.setString(7, f4);
			       ps.setString(8, choice4);
			       ps.setString(9, choice5);
			       ps.setString(10, subject);
			       ps.setString(11, question);
					int rr=ps.executeUpdate();
					if(rr>0)
					{
						System.out.println("Data Insert Done");
						response.sendRedirect("addquestion.jsp?insert");
						
						
					}
					else
					{
						System.out.println("Data Insert Failed");
						
						//response.sendRedirect("upload.jsp?insert=fail");
					}
				
			}
			catch(Exception e)
			{
				System.out.println("Exception Occures "+e);	
			}
		}
		else {
			System.out.println("2");
		}
	}
	private static String returnHex(byte[] inBytes) {
		String hexString = null;
	    for (int i=0; i < inBytes.length; i++) 
	    { //for loop ID:1
	        hexString +=
	        Integer.toString( ( inBytes[i] & 0xff ) + 0x100, 16).substring( 1 );
	    }                                   // Belongs to for loop ID:1
	return hexString;
	}
	
	public String Messagedigest(String filepath)throws Exception
	{
		BufferedImage buffImg = ImageIO.read(new File(filepath));
		 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		 ImageIO.write(buffImg, "png" ,outputStream);
		 byte[] data = outputStream.toByteArray();
		 MessageDigest md = MessageDigest.getInstance("MD5");
		 md.update(data);
	       byte[] hash = md.digest();
	       System.out.println(returnHex(hash).substring(4));
		return returnHex(hash).substring(4);
	}
}
