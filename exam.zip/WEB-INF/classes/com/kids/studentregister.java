package com.kids;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DbConnection;


@WebServlet("/studentregister")
public class studentregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public studentregister() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String gender = request.getParameter("gender");
		String dob = request.getParameter("dob");
		String class1 = request.getParameter("class");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String adrress = request.getParameter("address");
		String roll = request.getParameter("roll");
		String password = request.getParameter("password");//class
		
		try {
			Connection con = DbConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from studentreg where email=?");
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if(!rs.next())
			{
				PreparedStatement ps1 = con.prepareStatement("insert into studentreg(fname,lname,gender,class,email,mobile,address,roll,password,dob) values(?,?,?,?,?,?,?,?,?,?)");
				ps1.setString(1, fname);                                  
				ps1.setString(2, lname);
				ps1.setString(3, gender);
				ps1.setString(4, class1);
				ps1.setString(5, email);
				ps1.setString(6, mobile);
				ps1.setString(7, adrress);
				ps1.setString(8, roll);
				ps1.setString(9, password);
				ps1.setString(10, dob);
			
				ps1.executeUpdate();
				response.sendRedirect("studentregister.jsp?success");
			}
			else
			{
				response.sendRedirect("studentregister.jsp?present");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
