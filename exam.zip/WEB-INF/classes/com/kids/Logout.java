package com.kids;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.DbConnection;


@WebServlet("/Logout")
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Logout() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("Hellooo");
		
		
		try{
			Connection con = DbConnection.getConnection();
			Statement st = con.createStatement();
			//PreparedStatement ps = con.prepareStatement("SELECT * FROM `studentreg`");
			String userid = request.getParameter("studid");
			//String email = request.getParameter("username");
			System.out.println("studid:-"+userid);
			String class1 = request.getParameter("class");
			System.out.println("class:-"+class1);
			
			
			
			int rs = st.executeUpdate("update result set class ='"+class1+"' where userid='"+userid+"'");
			
			if(rs>0){
				//session.setAttribute("username", email);
				System.out.println("Updation successfull");
	           
	            response.sendRedirect("index.jsp?update");			
				
			}else{
				System.out.println("Updation failed");
					response.sendRedirect("result.jsp?update=fail");
				}
					
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
		
	}
