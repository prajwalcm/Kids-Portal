package com.kids;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DbConnection;

/**
 * Servlet implementation class addquestion
 */
@WebServlet("/addquestion")
public class addquestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addquestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String subject = request.getParameter("subject");
		String question = request.getParameter("question");
		String a = request.getParameter("a");
		String b = request.getParameter("b");
		String c = request.getParameter("c");
		String d = request.getParameter("d");
		String answer = request.getParameter("answer");
		
		try {
			Connection con = DbConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into exam(subject,question,a,b,c,d,answer) values(?,?,?,?,?,?,?)");
			ps.setString(1, subject);
			ps.setString(2, question);
			ps.setString(3, a);
			ps.setString(4, b);
			ps.setString(5, c);
			ps.setString(6, d);
			ps.setString(7, answer);
			ps.executeUpdate();
			
			response.sendRedirect("addquestion.jsp?done");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
