package NaiveBayes;

import com.util.DbConnection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/*import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;*/




import com.sun.xml.internal.txw2.Document;

import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;
import java.io.*;

public class CheckupNaive extends HttpServlet 
{
	Connection con = null;
	PreparedStatement ps;
	ResultSet rs;
	String subject;
	String question;
	String answer;
	
	 private double chisquareCriticalValue = 10.83; //equivalent to pvalue 0.001. It is used by feature selection algorithm
	    
	    private NaiveBayesKnowledgeBase knowledgeBase;
	    
	    
	    public void NaiveBayes(NaiveBayesKnowledgeBase knowledgeBase) {
	        this.knowledgeBase = knowledgeBase;
	    }
	    
	   
	    public void NaiveBayes() {
	      //  this(null);
	    }
	    
	   
	    public NaiveBayesKnowledgeBase getKnowledgeBase() {
	        return knowledgeBase;
	    }
	    
	    
	    public double getChisquareCriticalValue() {
	        return chisquareCriticalValue;
	    }
	    
	    
	    public void setChisquareCriticalValue(double chisquareCriticalValue) {
	        this.chisquareCriticalValue = chisquareCriticalValue;
	    }
	    
	    
	    private List<Document> preprocessDataset(Map<String, String[]> trainingDataset) {
	        List<Document> result = new ArrayList<>();
	                
	        String category;
	        String[] examples;
	        
	        Document input;
	        
	        Iterator<Map.Entry<String, String[]>> it = trainingDataset.entrySet().iterator();
	        
	       
	        while(it.hasNext()) {
	            Map.Entry<String, String[]> entry = it.next();
	            category = entry.getKey();
	            examples = entry.getValue();
	            
	            for(int i=0;i<examples.length;++i) {
	                //for each example in the category tokenize its text and convert it into a Document object.
	                input = TextTokenizer.tokenize(examples[i]);
	             
	                result.add(input);
	                
	               
	            }
	            
	        }
	        
	        return result;
	    }
	
	
}

