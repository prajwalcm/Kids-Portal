package NaiveBayes;

import com.util.DbConnection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import KnnAlgorithm.NearestNeighbour.DataEntry;

import com.mysql.jdbc.Statement;


@WebServlet("/check")
public class check extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	long start=System.currentTimeMillis();
	Connection con = null;
	PreparedStatement ps;
	Statement st;
	ResultSet rs;
	
	
    
    public check() {
    	try
		{
			
			con = DbConnection.getConnection();
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("exam=========================================================");
		
		HttpSession session = request.getSession();
		
		String subject = (String)session.getAttribute("subject");
		double subject9 = Double.parseDouble(subject);
		
		
		String question = (String)session.getAttribute("question");
		double question9 = Double.parseDouble(question);
		
		
		String answer = (String)session.getAttribute("answer");
		double answer9 = Double.parseDouble(answer);
		
			
		System.out.println("suject==1=="+subject);
		System.out.println("question==1=="+question);
		System.out.println("answer==1=="+answer);
		
		
		CheckupNaive naive;
		if(new CheckupNaive()!= null){
		Connection con = DbConnection.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("SELECT distinct result FROM exam WHERE subject='"+subject+"' AND question='"+question+"' AND answer='"+answer+"' ");
			ResultSet rs = ps.executeQuery();
			int count = 0;
			ArrayList<String> res = new ArrayList<String>();
			while(rs.next())
			{
			
				
				
				String Prediction = rs.getString("result");
				res.add(Prediction);
				
				
				count++;
				
				System.out.println("result=="+Prediction);
				
				
			}
			session.setAttribute("result", res);
			if(count>0)
			{
				long stop=System.currentTimeMillis();
		        long usert=stop-start;
		        
		       
		        System.out.println("Algorithm Search Time in M/S "+usert);
		        
		        try {
					PreparedStatement ps2 =con.prepareStatement("DELETE FROM `naivetime`");
					int r = ps2.executeUpdate();
					
					PreparedStatement ps1 = con.prepareStatement("INSERT INTO `naivetime`(`id`, `algotime`) VALUES (null,'"+usert+"')");
					int r1 = ps1.executeUpdate();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				response.sendRedirect("result.jsp");
				
			
			}
			else{
				PrintWriter out = response.getWriter();
		    	//out.println("Classified as: "+knn.classify(new DataEntry(new double[]{age9,sex9,cp9,trestbps9,chol9,fbs9,restecg9,thalach9,exang9,oldpeak9,slope9,ca9,thal9},"Ignore")));
		    	out.println("<html>");
				out.println("<body>");
				out.println("<center>");
				out.println("<h2 style='color:red;'>");
		    	out.println("Classified Result:please enter proper input.... ");
		    	out.println("</h2>");
				
				out.println("<a href=result.jsp><h2>Click Here To Go Back</h2></a>");
				out.println("<center>");
				out.println("</body>");
				out.println("</html>");
		    	
				
				
				
				
					out.close();
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
