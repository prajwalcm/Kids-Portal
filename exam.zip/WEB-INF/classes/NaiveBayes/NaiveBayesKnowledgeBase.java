package NaiveBayes;

public class NaiveBayesKnowledgeBase {

}
