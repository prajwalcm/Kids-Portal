package NaiveBayes;

import com.sun.xml.internal.txw2.Document;

public class TextTokenizer {

	public static Document tokenize(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
